# 净喵 CleanCat (Android)

一个本地运行的 Android 文件整理工具，面向 Android 11 及以上设备。

## 当前版本功能
- 通过 Android 系统文件夹选择器授权访问用户选定的目录
- 递归扫描 APK 安装包、0 字节文件、100 MB 以上的大文件
- 显示候选文件并由用户逐项勾选
- 删除前二次确认
- 不上传文件、不申请 Root、不读取其他应用私有数据

## 重要限制
Android 11 的分区存储机制不允许普通应用随意清理其他应用的私有缓存。本项目不会声称能一键清除所有 App 缓存。
重复文件哈希扫描、图片/视频分类、存储统计和更精细的清理规则尚未加入首版。

## 编译 APK
需要 Android Studio（建议 Koala 或更新版本）、JDK 17、Android SDK Platform 35。
1. 用 Android Studio 打开本目录。
2. 等待 Gradle Sync 完成。
3. 选择 Build > Build Bundle(s) / APK(s) > Build APK(s)。
4. APK 通常生成在 `app/build/outputs/apk/debug/app-debug.apk`。

## GitHub Actions
仓库包含 `.github/workflows/build.yml`。推送到 GitHub 后可在 Actions 页面下载构建产物。
