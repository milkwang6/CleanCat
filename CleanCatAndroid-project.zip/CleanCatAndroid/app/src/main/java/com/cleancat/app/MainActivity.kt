package com.cleancat.app

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.DocumentsContract.Document
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Typeface
import android.graphics.Color
import android.content.ContentUris
import java.util.concurrent.Executors
import java.security.MessageDigest
import java.util.Locale

data class FoundFile(
    val uri: Uri,
    val name: String,
    val size: Long,
    val kind: String,
    val detail: String
)

class MainActivity : Activity() {
    private val pickerCode = 4102
    private val worker = Executors.newSingleThreadExecutor()
    private var treeUri: Uri? = null
    private val results = mutableListOf<FoundFile>()
    private val selected = linkedSetOf<Uri>()
    private lateinit var status: TextView
    private lateinit var list: LinearLayout
    private lateinit var total: TextView
    private lateinit var scanButton: Button
    private lateinit var cleanButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 24, 22, 16)
            setBackgroundColor(Color.rgb(247, 248, 250))
        }
        val title = TextView(this).apply {
            text = "净喵 CleanCat"
            textSize = 26f
            setTextColor(Color.rgb(35, 42, 55))
            typeface = Typeface.DEFAULT_BOLD
        }
        page.addView(title)
        page.addView(TextView(this).apply {
            text = "本地存储整理工具 · 不上传文件 · 不需要 Root"
            textSize = 13f
            setTextColor(Color.DKGRAY)
            setPadding(0, 6, 0, 16)
        })
        val choose = Button(this).apply {
            text = "① 选择要扫描的文件夹"
            setOnClickListener { chooseFolder() }
        }
        page.addView(choose)
        scanButton = Button(this).apply {
            text = "② 开始扫描"
            isEnabled = false
            setOnClickListener { scan() }
        }
        page.addView(scanButton)
        status = TextView(this).apply {
            text = "请先选择手机内部存储或指定文件夹。"
            textSize = 14f
            setTextColor(Color.rgb(55, 65, 81))
            setPadding(0, 12, 0, 8)
        }
        page.addView(status)
        total = TextView(this).apply {
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(35, 42, 55))
            setPadding(0, 4, 0, 8)
        }
        page.addView(total)
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        cleanButton = Button(this).apply {
            text = "删除已勾选文件"
            isEnabled = false
            setOnClickListener { deleteSelected() }
        }
        page.addView(cleanButton)
        page.addView(TextView(this).apply {
            text = "注意：Android 不允许普通应用直接清理其他应用的私有缓存。请只勾选确认不需要的文件。"
            textSize = 12f
            setTextColor(Color.GRAY)
            setPadding(0, 8, 0, 0)
        })
        setContentView(page)
    }

    private fun chooseFolder() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or
                Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        startActivityForResult(intent, pickerCode)
    }

    @Deprecated("Deprecated in Android API but compatible with Android 11+")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickerCode && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            val flags = (data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION))
            contentResolver.takePersistableUriPermission(uri, flags)
            treeUri = uri
            scanButton.isEnabled = true
            status.text = "已选择文件夹，可以开始扫描。"
        }
    }

    private fun scan() {
        val root = treeUri ?: return
        scanButton.isEnabled = false
        cleanButton.isEnabled = false
        status.text = "正在扫描，请稍候……"
        results.clear()
        selected.clear()
        list.removeAllViews()
        worker.execute {
            val found = mutableListOf<FoundFile>()
            try {
                walk(root, found, 0)
            } catch (e: Exception) {
                runOnUiThread { status.text = "扫描遇到问题：${e.localizedMessage ?: "无法读取此目录"}" }
            }
            runOnUiThread {
                results.clear()
                results.addAll(found.sortedByDescending { it.size })
                showResults()
                scanButton.isEnabled = true
            }
        }
    }

    private fun walk(parent: Uri, output: MutableList<FoundFile>, depth: Int) {
        if (depth > 12 || output.size > 12000) return
        val docId = if (parent.path?.contains("/document/") == true) {
            DocumentsContract.getDocumentId(parent)
        } else {
            DocumentsContract.getTreeDocumentId(parent)
        }
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(parent, docId)
        contentResolver.query(
            children,
            arrayOf(Document.COLUMN_DOCUMENT_ID, Document.COLUMN_DISPLAY_NAME,
                Document.COLUMN_SIZE, Document.COLUMN_MIME_TYPE),
            null, null, null
        )?.use { cursor ->
            val idCol = cursor.getColumnIndex(Document.COLUMN_DOCUMENT_ID)
            val nameCol = cursor.getColumnIndex(Document.COLUMN_DISPLAY_NAME)
            val sizeCol = cursor.getColumnIndex(Document.COLUMN_SIZE)
            val mimeCol = cursor.getColumnIndex(Document.COLUMN_MIME_TYPE)
            while (cursor.moveToNext()) {
                val id = cursor.getString(idCol) ?: continue
                val name = cursor.getString(nameCol) ?: "未命名文件"
                val size = if (cursor.isNull(sizeCol)) 0L else cursor.getLong(sizeCol)
                val mime = cursor.getString(mimeCol) ?: ""
                val childUri = DocumentsContract.buildDocumentUriUsingTree(parent, id)
                if (mime == Document.MIME_TYPE_DIR) {
                    walk(childUri, output, depth + 1)
                } else {
                    val lower = name.lowercase(Locale.ROOT)
                    val kind = when {
                        lower.endsWith(".apk") -> "APK 安装包"
                        size == 0L -> "空文件"
                        size >= 100L * 1024 * 1024 -> "大文件"
                        else -> ""
                    }
                    if (kind.isNotEmpty()) {
                        output.add(FoundFile(childUri, name, size, kind, ""))
                    }
                }
            }
        }
    }

    private fun showResults() {
        list.removeAllViews()
        val bytes = results.sumOf { it.size }
        total.text = "找到 ${results.size} 个候选文件 · ${formatSize(bytes)}"
        status.text = if (results.isEmpty()) "没有发现 APK、空文件或超过 100 MB 的文件。" else
            "扫描完成。请逐项检查，勾选后再删除。"
        for (item in results) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(10, 8, 10, 8)
                setBackgroundColor(Color.WHITE)
            }
            val check = CheckBox(this).apply {
                text = "${item.kind}  ·  ${formatSize(item.size)}\n${item.name}"
                textSize = 14f
                setTextColor(Color.rgb(35, 42, 55))
                setOnCheckedChangeListener { _, checked ->
                    if (checked) selected.add(item.uri) else selected.remove(item.uri)
                    cleanButton.isEnabled = selected.isNotEmpty()
                    cleanButton.text = "删除已勾选文件（${selected.size}）"
                }
            }
            row.addView(check)
            list.addView(row)
            list.addView(View(this).apply {
                setBackgroundColor(Color.rgb(230, 233, 238))
            }, LinearLayout.LayoutParams(-1, 1))
        }
        cleanButton.isEnabled = false
        cleanButton.text = "删除已勾选文件"
    }

    private fun deleteSelected() {
        val targets = selected.toList()
        if (targets.isEmpty()) return
        android.app.AlertDialog.Builder(this)
            .setTitle("确认删除")
            .setMessage("将尝试删除 ${targets.size} 个已勾选文件。删除后通常无法恢复，确定继续吗？")
            .setNegativeButton("取消", null)
            .setPositiveButton("删除") { _, _ ->
                worker.execute {
                    var ok = 0
                    var fail = 0
                    targets.forEach {
                        try {
                            if (DocumentsContract.deleteDocument(contentResolver, it)) ok++ else fail++
                        } catch (_: Exception) { fail++ }
                    }
                    runOnUiThread {
                        selected.clear()
                        status.text = "删除完成：成功 $ok 个，失败 $fail 个。建议重新扫描确认。"
                        cleanButton.isEnabled = false
                        cleanButton.text = "删除已勾选文件"
                        scan()
                    }
                }
            }.show()
    }

    private fun formatSize(bytes: Long): String {
        if (bytes < 1024) return "$bytes B"
        val kb = bytes / 1024.0
        if (kb < 1024) return String.format(Locale.getDefault(), "%.1f KB", kb)
        val mb = kb / 1024.0
        if (mb < 1024) return String.format(Locale.getDefault(), "%.1f MB", mb)
        return String.format(Locale.getDefault(), "%.2f GB", mb / 1024.0)
    }

    override fun onDestroy() {
        super.onDestroy()
        worker.shutdown()
    }
}
